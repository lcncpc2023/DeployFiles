$("#add_secretaria").submit(function(event){
    alert("Dados inseridos com sucesso!!!");
})


$("#update_secretaria").submit(function(event){
    event.preventDefault();
    //returns all the submited data in a var
    var unindexed_array=$(this).serializeArray();
     
 
    var data={}

    $.map(unindexed_array, function(n,i){
        data[n['name']]=n['value']
        
    })
    console.log(data);
 
    var request = {
        "url": `http://localhost:3000/api/secretaria/${data.id}`,
        "method":"PUT",
        "data": data
    }

    $.ajax(request).done(function(response){
        alert("Dados actualizados com sucesso!");
    })  
})



if(window.location.pathname == "/secretaria"){
    $ondelete=$(".table tbody td a.delete");
    $ondelete.click(function(){
        var id=$(this).attr("data-id")
        var request = {
            "url": `http://localhost:3000/api/secretaria/${id}`,
            "method":"DELETE"
        }
        if(confirm("Tem certeza que pretende remover estes dados??  ")){
            $.ajax(request).done(function(response){
                alert("Dados removidos com sucesso");
                location.reload();
            })
        }

    


    })

}