const  express = require('express');
const route = express.Router();
const services = require('../services/render');
const controller = require('../controller/controller_secretaria');
const controller_paciente = require('../controller/controller_paciente');
const controller_psicologo = require('../controller/controller_psicologo');
const controller_sessao = require('../controller/controller_sessao');

route.get('/', services.homeRoutes);
route.get('/secretaria', services.secretaria);
route.get('/add-secretaria',services.add_secretaria)
route.get('/update-secretaria',services.update_secretaria)


//api routes for secretaria 
 route.post('/api/secretaria', controller.create); 
route.get('/api/secretaria', controller.find);
route.put('/api/secretaria/:id', controller.update);
route.delete('/api/secretaria/:id', controller.delete);


route.get('/paciente',services.paciente_homeRoutes) 
route.get('/add-paciente',services.add_paciente)
route.get('/update-paciente',services.update_paciente)  
//api paciente
route.post('/api/paciente', controller_paciente.create_paciente);
route.get('/api/paciente', controller_paciente.find_paciente);
route.put('/api/paciente/:id', controller_paciente.update_paciente);
route.delete('/api/paciente/:id', controller_paciente.delete_paciente);

// psicologo
route.get('/psicologo', services.psicologo)
route.get('/add-psicologo', services.add_psicologo)

route.get('/update-psicologo', services.update_psicologo)
//API
route.post('/api/psicologo', controller_psicologo.create);
route.get('/api/psicologo', controller_psicologo.find);
route.put('/api/psicologo/:id', controller_psicologo.update);
route.delete('/api/psicologo/:id', controller_psicologo.delete);

//sessao
route.get('/sessao',services.homeSessao);
route.get('/add-sessao',services.add_sessao);
route.get('/update-sessao',services.update_sessao);

route.post('/api/sessao', controller_sessao.create_sessao);
route.get('/api/sessao', controller_sessao.find_sessao);
route.put('/api/sessao/:id', controller_sessao.update_sessao);
route.delete('/api/sessao/:id', controller_sessao.delete_sessao);

route.get('/login',(req,res)=>{

    res.render('login');
})

route.get('/pacienteHome',(req,res)=>{
    res.render('pacienteHome');
});
route.get('/psicologoHome',(req,res)=>{
    res.render('psicologoHome');
});
route.get('/sessaoHome',(req,res)=>{
    res.render('sessaoHome');
});
route.get('/secretariaHome',(req,res)=>{
    res.render('secretariaHome');
});

module.exports= route