var Pacientedb= require('../model/model_paciente');
const { paciente } = require('../services/render');

//create and save new patiente
exports.create_paciente= (req,res)=>{
    //validate the request
    if(!req.body){
        res.status(400).send({message:" Deve preencher todos os campos!!"})
        return;
     }

     //new paciente
     const paciente=new Pacientedb({
        codigo: req.body.codigo,
        nome: req.body.nome,
        apelido: req.body.apelido,
        sexo: req.body.sexo,
        email: req.body.email,
        data_nasc: req.body.data_nasc,
        endereco: req.body.endereco,
        telefone: req.body.telefone,
        efermidade: req.body.efermidade,
        estado: req.body.estado
     })
       //save user into db
       paciente
       .save(paciente)
       .then(data=> {
          //redirect
          res.redirect('/add-paciente');
          //res.send(data)
       })
       .catch(err=>{
          res.status(500).send({
              message:err.message ||"Ocorreu algum erro durante o processo de gravacao de paciente"
          });
       }); 


}

// retrive and return a new paciente
exports.find_paciente = (req,res)=>{
    //if---- to return a single user
 
    if(req.query.id){
       const id =req.query.id;
       Pacientedb.findById(id)
       .then(data=>{
           if(!data){
               res.status(404).send({message:"Not found user with id ="+id})
           }else{
               res.send(data)
           }
       })
       .catch(err=>{
           res.status(500).send({message:"Erro retrieving user with id= "+id})
       })

   }else{
    Pacientedb.find()
   .then(paciente=>{
       res.send(paciente)
   })
   .catch(err=>{
       res.status(500).send({message:err.message || "Error occured while retriving user info"})
   })

   } 

}


// update a paciente
exports.update_paciente = (req,res)=>{
    if(!req.body){
        return res
        .status(400)
        .send({message:"Data to upgrade can not be empty"})
    }
    const id=req.params.id;

    Pacientedb.findByIdAndUpdate(id, req.body, {useFindAndModify: false})
        .then(data=>{
            if(!data){
                res.status(404).send({message:`Cannot Update user with ${id}. Maybe user not found`})
            }else{
                res.send(data)
            }
        })
        .catch(err=>{
            res.status(500).send({message:"Error Update user information"})
        })



}


// delete a paciente
exports.delete_paciente = (req,res)=>{
    const id=req.params.id;

    Pacientedb.findByIdAndDelete(id)
    .then(data=>{
        if(!data){
            res.status(404).send({message:`cannot delete with id${id}. Maybe id is wrong`})
        }else{
            res.send({
                message:"User was deleted successifuly"
            })
        }
    })
    .catch(err=>{
        res.status(500).send({
            message:"Could not delete user with id="+id
        });
    });


}