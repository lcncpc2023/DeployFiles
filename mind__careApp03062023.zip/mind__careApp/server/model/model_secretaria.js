const mongoose = require('mongoose');

var schema= new mongoose.Schema({
    codigo:{
        type: Number,
        required: true,
        unique: true

    },
    nome:{
        type: String,
        required:true
    },
    apelido:{
        type: String,
        required:true
    },
    sexo:{
        type: String,
        required:true
    },
    email:{
        type: String,
        required:true
    },
    data_nasc:{
        type: Date,
        required:true
    },
    endereco:{
        type: String,
        required:true
    },
    telefone:{
        type: String,
        required:true
    },
    nivel_exp:{
        type: String,
        required:true
    },
    idiomas:{
        type: String,
        required:true
    }
})
const Secretariadb= mongoose.model('secretariadb', schema);

module.exports=Secretariadb;