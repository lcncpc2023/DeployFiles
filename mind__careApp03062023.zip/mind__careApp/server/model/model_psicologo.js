const mongoose = require('mongoose');

var schema= new mongoose.Schema({
    codigo:{
        type: Number,
        required: true,
        unique: true
    },
    nome:{
        type: String,
        required:true,
        unique: true
    },
    apelido:{
        type: String,
        required:true
    },
    sexo:{
        type: String,
        required:true
    },
    email:{
        type: String,
        required:true
    },
    data_nasc:{
        type: Date,
        required:true
    },
    endereco:{
        type: String,
        required:true
    },
    telefone:{
        type: String,
        required:true
    },
    especialidade:{
        type: String,
        required:true
    },
    nivel_exp:{
        type: String,
        required:true
    },
    idiomas:{
        type: String,
        required:true
    }
})
const Psicologodb= mongoose.model('psicologodb', schema);

module.exports=Psicologodb;