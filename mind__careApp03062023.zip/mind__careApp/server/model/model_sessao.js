const mongoose = require('mongoose');

var schema= new mongoose.Schema({
    codigo:{
        type: Number,
        required:true,
        unique: true
       
    },
    data_inicio:{
        type: Date,
        required:true
    },
    data_fim:{
        type: Date,
        required:true
    },
    email_paciente:{
        type: String,
        required:true
    },
    email_psicologo:{
        type: String,
        required:true
    },
    duracao:{
        type: Number,
        required:true
    },
    efeitos:{
        type: String,
        required:true
    },
    tipo:{
        type: String,
        required:true
    },
    modelo:{
        type: String,
        required:true
    }
})
const Sessaodb= mongoose.model('sessaodb', schema);

module.exports=Sessaodb;