// SIDEBAR TOGGLE

var sidebarOpen = false;
var sidebar = document.getElementById("sidebar");

function openSidebar() {
  if(!sidebarOpen) {
    sidebar.classList.add("sidebar-responsive");
    sidebarOpen = true;
  }
}

function closeSidebar() {
  if(sidebarOpen) {
    sidebar.classList.remove("sidebar-responsive");
    sidebarOpen = false;
  }
}



// ---------- CHARTS ----------

// BAR CHART for principle causes
var barChartOptions = {
  series: [{
    data: [2, 4, 6, 7, 2] // here we add the nr of the cases
  }],
  chart: {
    type: 'bar',
    height: 350,
    toolbar: {
      show: false
    },
  },
  colors: [
    "#4f35a1",
    "#246dec",
    "#4f35a1",
    "#246dec",
    "#4f35a1"
  ],
  plotOptions: {
    bar: {
      distributed: true,
      borderRadius: 4,
      horizontal: false,
      columnWidth: '40%',
    }
  },
  dataLabels: {
    enabled: false
  },
  legend: {
    show: false
  },
  xaxis: {
    categories: ["Vícios", "Prob. familiares", "Prob. financeiros", "Genética", "Estresse"],
  },
  yaxis: {
    title: {
      text: "Causas da depressão"
    }
  }
};

var barChart = new ApexCharts(document.querySelector("#bar-chart"), barChartOptions);
barChart.render();


var barChartOptionsIdades = {
  series: [{
    data: [4, 2, 1, 4, 2] // here we add the nr of the cases
  }],
  chart: {
    type: 'bar',
    height: 350,
    toolbar: {
      show: false
    },
  },
  colors: [
    "#4f35a1",
    "#246dec",
    "#4f35a1",
    "#246dec",
    "#4f35a1"
    
  ],
  plotOptions: {
    bar: {
      distributed: true,
      borderRadius: 4,
      horizontal: false,
      columnWidth: '40%',
    }
  },
  dataLabels: {
    enabled: false
  },
  legend: {
    show: false
  },
  xaxis: {
    categories: ["10","15", "20", "25","30", "40", "50", "60", "70"],
  },
  yaxis: {
    title: {
      text: "Idades"
    }
  }
};

var barChart2 = new ApexCharts(document.querySelector("#bar-chart-idades"), barChartOptionsIdades);
barChart2.render();











// AREA CHART
var areaChartOptions = {
  series: [{
    name: 'Homens',
    data: [5, 2, 6, 9, 7, 5, 3]
  }, {
    name: 'Mulheres',
    data: [7, 5, 9, 5, 7, 6, 3]
  }],
  chart: {
    height: 350,
    type: 'area',
    toolbar: {
      show: false,
    },
  },
  colors: ["#4f35a1", "#246dec"],
  dataLabels: {
    enabled: false,
  },
  stroke: {
    curve: 'smooth'
  },
  labels: ["1º Mês", "2º Mês", "3º Mês", "4º Mês", "5º Mês", "6º Mês", "7º Mês"],
  markers: {
    size: 0
  },
  yaxis: [
    {
      title: {
        text: 'Intensidade dos efeitos',
      },
    },
    {
      opposite: true,
      title: {
        text: 'Intensidade dos efeitos',
      },
    },
  ],
  tooltip: {
    shared: true,
    intersect: false,
  }
};

var areaChart = new ApexCharts(document.querySelector("#area-chart"), areaChartOptions);
areaChart.render();