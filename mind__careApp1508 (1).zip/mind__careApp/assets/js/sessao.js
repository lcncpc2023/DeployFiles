
$("#add_sessao").submit(function(event){
    alert("Dados inseridos com sucesso!!!");
})

$("#update_sessao").submit(function(event){
    event.preventDefault();
    //returns all the submited data in a var
    var unindexed_array=$(this).serializeArray();
     
 
    var data={}

    $.map(unindexed_array, function(n,i){
        data[n['name']]=n['value']
        
    })
    console.log(data);
 
    var request = {
        "url": `http://localhost:3000/api/sessao/${data.id}`,
        "method":"PUT",
        "data": data
    }

    $.ajax(request).done(function(response){
        alert("Dados actualizados com sucesso!");
    })  
})


if(window.location.pathname == "/sessao"){
    $ondelete=$(".table tbody td a.delete");
    $ondelete.click(function(){
        var id=$(this).attr("data-id")
        var request = {
            "url": `http://localhost:3000/api/sessao/${id}`,
            "method":"DELETE"
        }
        if(confirm("Tem certeza que pretende remover estes dados?? ")){
            $.ajax(request).done(function(response){
                alert("Dados removidos com sucesso");
                location.reload();
            })
        }

    


    })

}