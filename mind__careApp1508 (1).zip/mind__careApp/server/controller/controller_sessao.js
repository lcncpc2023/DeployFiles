var Sessaodb = require('../model/model_sessao');
  
const { sessao } = require('../services/render');

var Pacientedb= require('../model/model_paciente');
const { paciente } = require('../services/render');

var Psicologodb= require('../model/model_psicologo');
const { psicologo } = require('../services/render');

exports.create_sessao =(req,res)=>{
    if(!req.body){
        res.status(400).send({message: "Conteudo nao pode estar vazio !!!"})
        return;
    }
    //new sessao
    const sessao=new Sessaodb({
        codigo:req.body.codigo,
        data_inicio:req.body.data_inicio,
        data_fim:req.body.data_fim,
        email_paciente:req.body.email_paciente,
        email_psicologo:req.body.email_psicologo,
        duracao:req.body.duracao,
        efeitos:req.body.efeitos,
        tipo:req.body.tipo,
        modelo:req.body.modelo

    })
    sessao
    .save(sessao)
    .then(data=>{
        res.redirect('/add-sessao');
    })
    .catch(err=>{
        res.status(500).send({
            message: err.message || "Occorreu um erro ao gravar a sessao"
        });
    });


}

exports.find_sessao =(req,res)=>{
    if(req.query.id){
        const id= req.query.id;
        Sessaodb.findById(id)
        .then(data=>{
            if(!data){
                res.send(404).send({message: "Sessao nao encontrada sessao com id= "+id})
            }else{
                res.send(data)
            }
        }) 
        .catch(err=>{
            res.status(500).send({message:"Erro ao listar o user com id= "+id})
        })

    }else{
        
        Sessaodb.find()
            .then(sessao=>{
                res.send(sessao)
            })
            .catch( sessao=>{
                res.status(500).send({message:message|| "Erro ao listar sessao"})
            })

        }
    
}
 
exports.update_sessao =(req,res)=>{
    if(!req.body){
        return res
        .status(400)
        .send({message: "Dados a actualizar devem estar completos"})

    }
    const id=req.params.id;
     Sessaodb.findByIdAndUpdate(id, req.body, {useFindAndModify:false  })
     .then(data=>{
        if(!data){
            res.status(404).send({message: `Cannot update the sessao with id ${id}`})
        }else{
            res.send(data)
        }
     })
     .catch(err=>{
        res.status(500).send({message:"erro ao actualizar informacao"})
     })
    
}

exports.delete_sessao =(req,res)=>{
    const id=req.params.id;
    Sessaodb.findByIdAndDelete(id)
    .then(data=>{
        if(!data){
            res.status(404).send({message: `Nao foi possivel actualizar o sessao com id ${id}`})
        }else{
            res.send({
                message: "Sessao removida com sucesso!"
            })
        }
    })
    .catch(err=>{
        res.status(500).send({
            message: "Nao foi possivel remover a sessao with id= "+id 
        });
    });    
} 




exports.find_allPacientePsicologo = async (req,res)=>{ 
    let data = await getData() 
    res.send(data)
}


async function getData(){
    let pacientes  = await Pacientedb.find()
    let psicologos = await Psicologodb.find() 
    let sessoes = await Sessaodb.find()

    return {pacientes:pacientes, psicologos:psicologos, sessoes:sessoes}
}