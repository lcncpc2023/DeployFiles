var Psicologodb= require('../model/model_psicologo');
const { psicologo } = require('../services/render');


exports.create= (req,res)=>{
    //validate the request
    if(!req.body){
        res.status(400).send({message:"Content cannot be empty!!"})
        return;
     }

     //new psicologo
     const psicologo=new Psicologodb({
        codigo: req.body.codigo,
        nome: req.body.nome,
        apelido: req.body.apelido,
        sexo: req.body.sexo,
        email: req.body.email,
        data_nasc: req.body.data_nasc,
        endereco: req.body.endereco,
        telefone: req.body.telefone,
        especialidade: req.body.especialidade,
        nivel_exp: req.body.nivel_exp,
        idiomas: req.body.idiomas,
        password: req.body.password

     })
       //save user into db
       psicologo
       .save(psicologo)
       .then(data=> {
          //redirect
          res.redirect('/add-psicologo');
          //res.send(data)
       })
       .catch(err=>{
          res.status(500).send({
              message:err.message ||"Some error ocurred while creating a create operation"
          });
       }); 


}
// retrive and return a new psicologo
exports.find = (req,res)=>{
     //if---- to return a single user
     if(req.query.id){
        const id =req.query.id;
        Psicologodb.findById(id)
        .then(data=>{
            if(!data){
                res.status(404).send({message:"Not found user with id ="+id})
            }else{
                res.send(data)
            }
        })
        .catch(err=>{
            res.status(500).send({message:"Erro retrieving user with id= "+id})
        })

    }else{
        Psicologodb.find()
    .then(psicologo=>{
        res.send(psicologo)
    })
    .catch(err=>{
        res.status(500).send({message:err.message || "Error occured while retriving user info"})
    })

    }
    


}

// update a psicologo
exports.update = (req,res)=>{
    if(!req.body){
        return res
        .status(400)
        .send({message:"Data to upgrade can not be empty"})
    }
    const id=req.params.id;

    Psicologodb.findByIdAndUpdate(id, req.body, {useFindAndModify: false})
        .then(data=>{
            if(!data){
                res.status(404).send({message:`Cannot Update user with ${id}. Maybe user not found`})
            }else{
                res.send(data)
            }
        })
        .catch(err=>{
            res.status(500).send({message:"Error Update user information"})
        })



}

// delete a psicologo
exports.delete = (req,res)=>{
    const id=req.params.id;

    Psicologodb.findByIdAndDelete(id)
    .then(data=>{
        if(!data){
            res.status(404).send({message:`cannot delete with id${id}. Maybe id is wrong`})
        }else{
            res.send({
                message:"User was deleted successifuly"
            })
        }
    })
    .catch(err=>{
        res.status(500).send({
            message:"Could not delete user with id="+id
        });
    });


}