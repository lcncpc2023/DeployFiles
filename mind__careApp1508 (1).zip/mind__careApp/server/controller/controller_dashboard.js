

var Pacientedb= require('../model/model_paciente');
const { paciente } = require('../services/render');

var Psicologodb= require('../model/model_psicologo');
const { psicologo } = require('../services/render');


var Secretariadb= require('../model/model_secretaria');
const { secretaria } = require('../services/render');


var Sessaodb = require('../model/model_sessao');
const { sessao } = require('../services/render');


// find the data
exports.find_allData = async (req,res)=>{
   /*  Pacientedb.find()
    Psicologodb.find()
    Secretariadb.find()
    
    Sessaodb.find()
    .then(paciente=>{
        res.send(paciente)
    })
    .then(psicologo=>{
        res.send(psicologo)
    })
    .catch(err=>{
        res.status(500).send({message:err.message || "Error occured while retriving user info"})
    }) */
 //   let data = await  getGenero()

    
   // console.log(data.paciente)
     let data = await getData()
    //res.send(JSON.stringify(data))


    res.send(data)


}

async function getData(){
    let paciente = await Pacientedb.find()
    let psicologo = await Psicologodb.find()
    let secretaria = await Secretariadb.find()
    let sessao = await Sessaodb.find()

    let pacientes = await Pacientedb.find()
    let masc=0;
    let fem=0;

    pacientes.forEach(paciente =>{
        if (paciente.sexo === "Masculino"){
            masc++
        }else{
            fem++
        }    
    })



    return {paciente:paciente.length, psicologo:psicologo.length, secretaria:secretaria.length, sessao:sessao.length, masc:masc, fem:fem}
}


async function getGenero(){
    let pacientes = await Pacientedb.find()
    let masc=0;
    let fem=0;

    pacientes.forEach(paciente =>{
        if (paciente.sexo === "Masculino"){
            masc++
        }else{
            fem++
        }    
    })

  /*   for(let i=0; i<pacientes.length;i++ ){
        if(pacientes[i].sexo ==="Masculino"){
            masc++;
        }else{
            fem++;
        }
    }
 */


    return {paciente:masc, psicologo:fem, secretaria:0, sessao:0}
}