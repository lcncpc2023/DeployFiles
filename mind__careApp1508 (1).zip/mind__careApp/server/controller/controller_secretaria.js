
var Secretariadb= require('../model/model_secretaria');
const { secretaria } = require('../services/render');
//Secretaria

//create
exports.create=(req,res)=>{
    if(!req.body){
        res.status(400).send({ message : "O conteudo nao pode estar vazio"});
        return;
    }
    const secretaria= new Secretariadb({
        codigo: req.body.codigo,
        nome: req.body.nome,
        apelido: req.body.apelido,
        sexo: req.body.sexo,
        email: req.body.email,
        data_nasc: req.body.data_nasc,
        endereco: req.body.endereco,
        telefone: req.body.telefone,
        nivel_exp: req.body.nivel_exp,
        idiomas: req.body.idiomas,
        password: req.body.password

    })
    secretaria
    .save(secretaria)
    .then(data=>{
        //res.send(data)
        res.redirect('/add-secretaria');
    })
    .catch(err=>{
        res.status(500).send({
            message:err.message || "Occoreu algum erro a criar a nova secretaria"
        });
    });
}


//retrive
exports.find=(req, res)=>{
    if(req.query.id){
        const id=req.query.id;
        Secretariadb.findById(id)
            .then(data=>{
                if(!data){
                    res.status(404).send({message: "Not found secretaria with id"+ id})
                }else{
                    res.send(data)
                }

            })
            .catch(err=>{
                res.status(500).send({message: "Error retriving user with id "+ id})
            })

    }else{
            Secretariadb.find()
        .then(secretaria=>{
            res.send(secretaria)
        })
        .catch(err=>{
            res.status(500).send({message : err.message || "Some error occured while list a secretaria"})
        })
    }
   
}

//update
exports.update=(req, res)=>{
   
    if(!req.body){
        return res
        .status(400)
        .send({message: "A info a actualizar n pode estar vazia"})
    }
    const id=req.params.id;
    Secretariadb.findByIdAndUpdate(id, req.body, { useFindAndModify: false})
    .then(data=>{
         if(!data){
            res.status(404).send({message: `Cannot Update user with id ${id}, Maybe it wasnt found!!`})
         }else{
            res.send(data)
         }
    })
    .catch(err=>{
        res.status(500).send({message:"Error on updating user info"})
    })
}

//delete
exports.delete=(req, res)=>{
    const id=req.params.id;
    Secretariadb.findByIdAndDelete(id)
    .then(data=>{
        if(!data){
            res.status(404).send({message: `Cannot delete with id ${id}`})
        }else{
            res.send({
                message: "Secretaria was deleted sucessifuly!"
            })
        }
    })
    .catch(err=>{
        res.status(500).send({
            message:"Couldnt delete the secretaria with id"+ id
        });
    });

}

