const mongoose = require('mongoose');

var schema= new mongoose.Schema({
    codigo:{
        type: Number,
        required: true

    },
    nome:{
        type: String,
        required:true
    },
    apelido:{
        type: String,
        required:true
    },
    sexo:{
        type: String,
        required:true
    },
    email:{
        type: String,
        required:true,
        unique: true

    },
    data_nasc:{
        type: String,
        required:true
    },
    endereco:{
        type: String,
        required:true
    },
    telefone:{
        type: String,
        required:true
    },
    nivel_exp:{
        type: String,
        required:true
    },
    idiomas:{
        type: String,
        required:true
    },
    password:{
        type: String,
        required:true
    }
})
const Secretariadb= mongoose.model('secretariadb', schema);

module.exports=Secretariadb;