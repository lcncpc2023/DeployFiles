const mongoose = require('mongoose');

var schema= new mongoose.Schema({
    codigo: {
        type:Number,
        required:true
    },
    nome:{
        type: String,
        required:true
    },
    apelido:{
        type: String,
        required:true
    },
    sexo:{
        type: String,
        required:true
    },
    email:{
        type: String,
        required:true,
        unique:true
    },
    data_nasc:{
        type: String,
        required:true
    },
    endereco:{
        type: String,
        required:true
    },
    telefone:{
        type: String,
        required:true
    },
    efermidade:{
        type: String,
        required:true
    },
    estado:{
        type: String,
        required:true
    },
    password:{
        type: String,
        required:true
    }
})
const Pacientedb= mongoose.model('pacientedb', schema);

module.exports=Pacientedb;