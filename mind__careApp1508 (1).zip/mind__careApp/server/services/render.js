const axios = require('axios'); 



exports.homeRoutes= (req,res)=>{
    //Make  a get request  to /api/users
    res.render('index');
}

exports.secretaria= (req, res)=>{
    axios.get('http://localhost:3000/api/secretaria')
    .then(function(response){
        
         res.render('secretaria', {secretaria: response.data});        
    })
    .catch(
        err=>{
            res.send(err);

        }
    )

 
}

exports.add_secretaria= (req, res)=>{
    res.render('add_secretaria');
}

exports.update_secretaria= (req, res)=>{
    axios.get('http://localhost:3000/api/secretaria',{params:{id:req.query.id}})
    .then(function(secretariadata){
        res.render("update_secretaria", {secretaria:secretariadata.data})
    })
    .catch(err=>{
        res.send( err);
    })
   
}



//paciente
exports.paciente_homeRoutes= (req,res)=>{

    //   res.render('paciente',  {pacientes:response.data});
     
       axios.get('http://localhost:3000/api/paciente')
       .then(function(response){ 
           //console.log(response.data);
           res.render('paciente', {paciente:response.data});
       })
       .catch(err=>{
           res.send(err);
       })
     //  
    
   }
    
 
   exports.paciente_details = (req,res)=>{

    //   res.render('paciente',  {pacientes:response.data});
    axios.get('http://localhost:3000/api/paciente',{params:{id:req.query.id}})
 
        .then(function(pacientedata){
            res.render("pacienteDetails",{ paciente:pacientedata.data})
        })
        .catch(err=>{
            res.send(err);
        })
    
  
   }



   
   exports.add_paciente= (req,res)=>{
       res.render('add_paciente');
   }
   
   
   exports.update_paciente= (req,res)=>{ 
       axios.get('http://localhost:3000/api/paciente',{params:{id:req.query.id}})
       .then(function(pacientedata){
           res.render("update_paciente",{ paciente:pacientedata.data})
       })
       .catch(err=>{
           res.send(err);
       })
   
       
   }
    







   // psicologo
   exports.psicologo= (req,res)=>{
    axios.get('http://localhost:3000/api/psicologo')
    .then(function(response){ 
        console.log(response.data);
        res.render('psicologo',  {psicologo:response.data}); 
    })
    .catch(err=>{
        res.send(err);
    })
}
 
exports.add_psicologo= (req,res)=>{
    res.render('add_psicologo');
}

exports.update_psicologo= (req,res)=>{ 
    // to push the data of the user to the inputs
    axios.get('http://localhost:3000/api/psicologo', {params:{id:req.query.id}})
    .then(function(psicologodata){
        res.render("update_psicologo", {psicologo:psicologodata.data})
    })
    .catch(err=>{
        res.send(err);
    }) 
}

exports.psicologo_details = (req,res)=>{

    //   res.render('paciente',  {pacientes:response.data});
    axios.get('http://localhost:3000/api/psicologo',{params:{id:req.query.id}})
 
        .then(function(psicologodata){
            res.render("psicologoDetails",{ psicologo:psicologodata.data})
        })
        .catch(err=>{
            res.send(err);
        })
}

exports.sessao_details = (req,res)=>{

    //   res.render('paciente',  {pacientes:response.data});
    axios.get('http://localhost:3000/api/versessao',{params:{id:req.query.id}})
 
        .then(function(sessaodata){
            res.render("sessaoDetails",{ sessao:sessaodata.data})
        })
        .catch(err=>{
            res.send(err);
        })
}




//sessao

exports.homeSessao=(req,res)=>{
    axios.get('http://localhost:3000/api/versessao')
    .then(function(response){
        res.render('sessao', {sessoes: response.data});
    })
    .catch(
        err=>{
            res.send(err);

        }
    )
}



exports.add_sessao=(req,res)=>{
    axios.get('http://localhost:3000/api/sessao')
    .then(function(response){
        res.render('add_sessao', {data: response.data});
    })
    .catch(
        err=>{
            res.send(err);

        }
    )
}

exports.update_sessao=(req,res)=>{
    axios.get('http://localhost:3000/api/sessao',{params:{id:req.query.id}})
    .then(function(sessaodata){
        res.render("update_sessao", {sessao:sessaodata.data})
    })
    .catch(err=>{
        res.send( err);
    })
}
   


//Dashboard
exports.dashboard=(req,res)=>{
    axios.get('http://localhost:3000/api/dashboard')
    .then(function(response){
        res.render('dashboard', {data: response.data});
    })
    .catch(
        err=>{
            res.send(err);

        }
    )
}