const  express = require('express');
const route = express.Router();
const services = require('../services/render');
const controller = require('../controller/controller_secretaria');
const controller_paciente = require('../controller/controller_paciente');

route.get('/', services.homeRoutes);
route.get('/secretaria', services.secretaria);
route.get('/add-secretaria',services.add_secretaria)
route.get('/update-secretaria',services.update_secretaria)


//api routes for secretaria 
 route.post('/api/secretaria', controller.create); 
route.get('/api/secretaria', controller.find);
route.put('/api/secretaria/:id', controller.update);
route.delete('/api/secretaria/:id', controller.delete);


route.get('/paciente',services.paciente_homeRoutes) 
route.get('/add-paciente',services.add_paciente)
route.get('/update-paciente',services.update_paciente)  
//api paciente
route.post('/api/paciente', controller_paciente.create_paciente);
route.get('/api/paciente', controller_paciente.find_paciente);
route.put('/api/paciente/:id', controller_paciente.update_paciente);
route.delete('/api/paciente/:id', controller_paciente.delete_paciente);


module.exports= route