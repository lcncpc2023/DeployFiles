const axios = require('axios'); 



exports.homeRoutes= (req,res)=>{
    //Make  a get request  to /api/users
    res.render('index');
}

exports.secretaria= (req, res)=>{
    axios.get('http://localhost:3000/api/secretaria')
    .then(function(response){
        
         res.render('secretaria', {secretaria: response.data});        
    })
    .catch(
        err=>{
            res.send(err);

        }
    )

 
}

exports.add_secretaria= (req, res)=>{
    res.render('add_secretaria');
}

exports.update_secretaria= (req, res)=>{
    axios.get('http://localhost:3000/api/secretaria',{params:{id:req.query.id}})
    .then(function(secretariadata){
        res.render("update_secretaria", {secretaria:secretariadata.data})
    })
    .catch(err=>{
        res.send( err);
    })
   
}



//paciente
exports.paciente_homeRoutes= (req,res)=>{

    //   res.render('paciente',  {pacientes:response.data});
     
       axios.get('http://localhost:3000/api/paciente')
       .then(function(response){ 
           //console.log(response.data);
           res.render('paciente', {paciente:response.data});
       })
       .catch(err=>{
           res.send(err);
       })
     //  
    
   }
    
   
   exports.add_paciente= (req,res)=>{
       res.render('add_paciente');
   }
   
   
   exports.update_paciente= (req,res)=>{ 
       axios.get('http://localhost:3000/api/paciente',{params:{id:req.query.id}})
       .then(function(pacientedata){
           res.render("update_paciente",{ paciente:pacientedata.data})
       })
       .catch(err=>{
           res.send(err);
       })
   
       
   }
    
   