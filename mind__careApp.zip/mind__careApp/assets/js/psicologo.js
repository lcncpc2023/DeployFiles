
$("#add_psicologo").submit(function(event){
    alert("Dados inseridos com sucesso!!!");
})


$("#update_psicologo").submit(function(event){
    event.preventDefault();
    //returns all the submited data in a var
    var unindexed_array=$(this).serializeArray();
    var data={}

    $.map(unindexed_array, function(n,i){
        data[n['name']]=n['value']
        
    })
    console.log(data);

    var request = {
        "url": `http://localhost:3000/api/psicologo/${data.id}`,
        "method":"PUT",
        "data": data
    }

    $.ajax(request).done(function(response){
        alert("Dados actualizados com sucesso!");
    })
})

//delete request
if(window.location.pathname == "/psicologo"){
    $ondelete=$(".table tbody td a.delete");
    $ondelete.click(function(){
        var id=$(this).attr("data-id")
        var request = {
            "url": `http://localhost:3000/api/psicologo/${id}`,
            "method":"DELETE"
        }
        if(confirm("Do you really want to delete this reccord?? ")){
            $.ajax(request).done(function(response){
                alert("Dados removidos com sucesso");
                location.reload();
            })
        }

    


    })

}